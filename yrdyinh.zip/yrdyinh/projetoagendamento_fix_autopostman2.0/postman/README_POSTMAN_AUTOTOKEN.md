# Postman (Auto Token)

1) Importe a Collection: `ProjetoAgendamento_AutoToken.postman_collection.json`
2) Importe o Environment: `ProjetoAgendamento_DEV.postman_environment.json`
3) Selecione o environment **ProjetoAgendamento DEV** no topo do Postman.
4) Preencha as variáveis `email` e `senha` (no Environment).
5) Rode o request **Auth > Login (salva token)**. O token será salvo automaticamente em `token`.
6) Agora qualquer request da collection vai mandar o header Authorization automaticamente.
7) Para rodar tudo de uma vez: clique na collection > Run.

Variáveis úteis:
- `ticketId` (para aprovar/reprovar)
- `adminId` e `assignedTo`
