import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart'; // Para debugPrint

// URL base do seu backend
const String API_BASE_URL = 'https://projetoagendamento-n20v.onrender.com';
const Duration TIMEOUT_DURATION = Duration(seconds: 15);

// Classe de Exceção para erros de API específicos
class ApiException implements Exception {
  final String message;
  final int statusCode;
  ApiException(this.message, [this.statusCode = 0]);

  @override
  String toString() => 'ApiException [$statusCode]: $message';
}

class AdminService {
  final String authToken;

  AdminService({required this.authToken});

  Map<String, String> _getHeaders() {
    return {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $authToken',
    };
  }

  /// Tenta decodificar JSON com segurança.
  ///
  /// - Retorna `Map<String, dynamic>` quando o body é um objeto JSON.
  /// - Retorna `null` quando o body está vazio ou não é um objeto JSON.
  Map<String, dynamic>? _tryDecodeJsonObject(String body) {
    final trimmed = body.trim();
    if (trimmed.isEmpty) return null;
    try {
      final decoded = json.decode(trimmed);
      if (decoded is Map<String, dynamic>) return decoded;
      return null;
    } catch (_) {
      return null;
    }
  }

  ApiException _buildApiException({
    required http.Response response,
    required String fallbackMessage,
  }) {
    final obj = _tryDecodeJsonObject(response.body);
    final msg =
        obj?['error'] ?? obj?['message'] ?? fallbackMessage;

    // Ajuda no debug quando o backend devolve HTML (ex: 502/504) ou body vazio.
    if (obj == null) {
      final preview = response.body.trim();
      final shortPreview =
          preview.length > 160 ? '${preview.substring(0, 160)}…' : preview;
      return ApiException(
        '$msg (resposta não-JSON: "$shortPreview")',
        response.statusCode,
      );
    }

    return ApiException(msg.toString(), response.statusCode);
  }

  // --- BUSCAR TÉCNICOS (GET /users) ---
  // Retorna uma lista de Map<String, dynamic> para ser mapeada para o modelo User fora do Service.
  Future<List<dynamic>> fetchTechniciansData() async {
    final url = Uri.parse('$API_BASE_URL/users');
    try {
      final response =
          await http.get(url, headers: _getHeaders()).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['users'] is List) {
          // Filtra aqui, mas você pode deixar o filtro 'tech' no Dashboard para flexibilidade.
          // Por enquanto, retorna a lista bruta para ser filtrada no ViewModel/Widget.
          return data['users'];
        }
        throw ApiException('Formato de resposta inesperado ao buscar usuários.',
            response.statusCode);
      } else {
        throw _buildApiException(
          response: response,
          fallbackMessage: 'Falha ao carregar técnicos.',
        );
      }
    } catch (e) {
      debugPrint('Erro em fetchTechnicians: $e');
      rethrow; // Propaga a exceção para ser tratada na UI
    }
  }

  // --- BUSCAR TICKETS (GET /ticket) ---
  Future<List<dynamic>> fetchTicketsData() async {
    final url = Uri.parse('$API_BASE_URL/ticket');
    try {
      final response =
          await http.get(url, headers: _getHeaders()).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = _tryDecodeJsonObject(response.body);
        if (data == null) {
          // Se o backend devolveu um body vazio/inesperado, trate como erro.
          throw ApiException(
            'Resposta inesperada ao carregar tickets (body vazio ou inválido).',
            response.statusCode,
          );
        }
        return (data['tickets'] is List) ? (data['tickets'] as List) : [];
      } else {
        throw _buildApiException(
          response: response,
          fallbackMessage: 'Falha ao carregar tickets.',
        );
      }
    } catch (e) {
      debugPrint('Erro em fetchTickets: $e');
      rethrow;
    }
  }

  // --- REPROVAR TICKET (PUT /ticket/:id/reject) ---
  Future<void> rejectTicket({
    required String ticketId,
    required int adminId,
  }) async {
    final url = Uri.parse('$API_BASE_URL/ticket/$ticketId/reject');
    try {
      final response = await http
          .put(
            url,
            headers: _getHeaders(),
            body: json.encode({'admin_id': adminId}),
          )
          .timeout(TIMEOUT_DURATION);

      if (response.statusCode != 200) {
        throw _buildApiException(
          response: response,
          fallbackMessage: 'Falha ao reprovar ticket.',
        );
      }
    } catch (e) {
      debugPrint('Erro em rejectTicket: $e');
      rethrow;
    }
  }

  // --- APROVAR E ATRIBUIR TICKET (PUT /ticket/:id/approve) ---
  Future<void> approveTicket({
    required String ticketId,
    required int adminId,
    required int assignedToId,
  }) async {
    final url = Uri.parse('$API_BASE_URL/ticket/$ticketId/approve');
    try {
      final response = await http
          .put(
            url,
            headers: _getHeaders(),
            body: json.encode({
              'admin_id': adminId,
              'assigned_to': assignedToId,
            }),
          )
          .timeout(TIMEOUT_DURATION);

      if (response.statusCode != 200) {
        throw _buildApiException(
          response: response,
          fallbackMessage: 'Falha ao aprovar ticket.',
        );
      }
    } catch (e) {
      debugPrint('Erro em approveTicket: $e');
      rethrow;
    }
  }
}
