-- =========================================================
-- ProjetoAgendamento - Neon/Postgres Schema (v3)
-- - Usuários (admin/seller/tech)
-- - Clientes
-- - Tickets com rastreio de tempo (started_at/completed_at)
-- - Localização (lat/lng) para integração com Maps
-- - Índices e trigger updated_at
-- =========================================================

BEGIN;

-- Extensão útil (opcional) para UUID se você quiser no futuro
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------
-- users
-- -----------------------------
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(30),
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role VARCHAR(30) NOT NULL CHECK (role IN ('tech','seller','admin')),
  fcm_token TEXT,
  created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);

-- -----------------------------
-- customers
-- -----------------------------
CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  address TEXT NOT NULL,
  identifier VARCHAR(50) UNIQUE NOT NULL, -- CPF/CNPJ (normalizado no app/backend)
  phone_number VARCHAR(20),
  created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);

-- -----------------------------
-- tickets
-- -----------------------------
CREATE TABLE IF NOT EXISTS tickets (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  priority VARCHAR(50) NOT NULL DEFAULT 'NORMAL',
  customer_id INT REFERENCES customers(id),
  customer_name VARCHAR(255) NOT NULL,
  customer_address TEXT NOT NULL,

  -- localização (pra Maps)
  customer_lat DOUBLE PRECISION,
  customer_lng DOUBLE PRECISION,

  requested_by INT NOT NULL REFERENCES users(id),
  assigned_to INT REFERENCES users(id),

  -- status admin (workflow)
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING','APPROVED','REJECTED')),

  approved_by INT REFERENCES users(id),
  approved_at TIMESTAMP WITHOUT TIME ZONE,

  -- status do técnico (execução)
  tech_status VARCHAR(50),
  started_at TIMESTAMP WITHOUT TIME ZONE,
  completed_at TIMESTAMP WITHOUT TIME ZONE,

  last_updated_by INT REFERENCES users(id),
  created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);

-- -----------------------------
-- ticket_attachments
-- -----------------------------
CREATE TABLE IF NOT EXISTS ticket_attachments (
  id SERIAL PRIMARY KEY,
  ticket_id INT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);

-- -----------------------------
-- Indexes
-- -----------------------------
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_customers_identifier ON customers(identifier);
CREATE INDEX IF NOT EXISTS idx_tickets_assigned_to ON tickets(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tickets_requested_by ON tickets(requested_by);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_tech_status ON tickets(tech_status);
CREATE INDEX IF NOT EXISTS idx_tickets_completed_at ON tickets(completed_at);

-- -----------------------------
-- updated_at trigger helper
-- -----------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_users_updated_at') THEN
    CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE PROCEDURE set_updated_at();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_customers_updated_at') THEN
    CREATE TRIGGER trg_customers_updated_at
    BEFORE UPDATE ON customers
    FOR EACH ROW EXECUTE PROCEDURE set_updated_at();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_tickets_updated_at') THEN
    CREATE TRIGGER trg_tickets_updated_at
    BEFORE UPDATE ON tickets
    FOR EACH ROW EXECUTE PROCEDURE set_updated_at();
  END IF;
END $$;

COMMIT;

-- =========================================================
-- Relatório: resumo por técnico (últimos 30 dias)
-- =========================================================
-- SELECT u.id, u.name,
--        COUNT(t.id) AS services_completed,
--        ROUND(COALESCE(SUM(EXTRACT(EPOCH FROM (t.completed_at - t.started_at))/60),0)::numeric,2) AS total_minutes
-- FROM users u
-- LEFT JOIN tickets t ON t.assigned_to = u.id
--   AND t.tech_status='COMPLETED'
--   AND t.completed_at >= (now() - interval '30 days')
-- WHERE u.role='tech'
-- GROUP BY u.id, u.name
-- ORDER BY services_completed DESC;
